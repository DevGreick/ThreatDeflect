from .threatdeflect_rs import *

__doc__ = threatdeflect_rs.__doc__
if hasattr(threatdeflect_rs, "__all__"):
    __all__ = threatdeflect_rs.__all__